import React,{Component} from 'react'

import AuthenticationService from './AuthenticationService.js'
import "./login.css"
class LoginComponent extends Component{
    constructor(props){
        super(props)
        this.state= {
            username:"raihan",
            password:"raihan",
            showCredential:false,
            successUrl: false
        }

        this.handleFormChange = this.handleFormChange.bind(this)
       this.loginCheck = this.loginCheck.bind(this);
    }

    handleFormChange(event){
        console.log(event.target.value);
        this.setState(
           {
            [event.target.name]:event.target.value
           }
        )
    }

    loginCheck(){
        if(this.state.username==='raihan'&&this.state.password==='raihan'){
            AuthenticationService.registerSuccessfullLogin(this.state.username,this.state.password)
            this.props.history.push(`/welcome/${this.state.username}`)
        //   this.setState({
        //     showCredential:false,
        //     succesUrl:true
        //   })
        }else{
            this.setState({
                showCredential:true,
                succesUrl:false
              })
        }
    }

    render(){
        return (
            <div>
                {/* <LoginCredential showCredential={this.state.showCredential}/> */}
                {this.state.showCredential && <h3 className="alert alert-warning">Invalid Credential, Login Failed</h3> }
                 <h1>My Todo Application</h1>
                Username:<input type="text" id="username" name="username" value={this.state.username} onChange={this.handleFormChange}/>
                Password:<input type="password" id ="password" name ="password" value={this.state.password} onChange={this.handleFormChange}/>
                <button className='btn btn-success' onClick={this.loginCheck}>Login</button>
            </div>
        )
    }
}
export default LoginComponent;