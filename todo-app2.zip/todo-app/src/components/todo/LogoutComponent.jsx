import React,{Component} from 'react'
class LogoutComponent extends Component{
    render(){
        return (
            <div>
                <h3>You have successfully logged out</h3>
            </div>
        )
    }
}
export default LogoutComponent;