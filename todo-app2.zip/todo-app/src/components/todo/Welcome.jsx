import React,{Component} from 'react'

import {BrowserRouter as Router,Route,Switch,Link}  from 'react-router-dom'
class Welcome extends Component{
    render(){
        return <div><h1>Welcome {this.props.match.params.name}</h1>
        <p>go to your Todos <Link to="/todos">here</Link></p>
        </div>
    }
}
export default Welcome