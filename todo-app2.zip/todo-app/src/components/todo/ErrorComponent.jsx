import React,{Component} from 'react'

function ErrorComponent(){
    return <div><h3>An error has been error</h3></div>
}
export default ErrorComponent;