import React,{Component} from 'react'
class FirstComponent extends Component{
    render(){
      return (
        <div>
          <h1>First component </h1>
        </div>
      )
    }
  }

  export default FirstComponent;