import React from 'react';
import TodoApp from './components/todo/TodoApp'
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"

function App() {
  return (
    <div className="App">
      
         <div className="container">
         <TodoApp/>
         </div>
        
   
    
    </div>
  );
}


export default App;
